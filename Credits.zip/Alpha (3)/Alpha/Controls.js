class Controls extends Phaser.Scene{
    constructor(){
        super("Controls");
    }
    
    preload(){
        this.load.image('controls', 'assets/images/controls.png');
        this.load.image('play', 'assets/images/play.png');
        this.load.audio('click', 'assets/audio/button.mp3');
    }
    
    create(){
        let playButton = this.add.image(this.game.renderer.width / 1.15, this.game.renderer.height / 1.1, 'play').setDepth(1);
        
        this.add.image(0,0, 'controls').setOrigin(0);
        
        this.click = this.sound.add("click");
        
        playButton.setInteractive();
        
        playButton.on('pointerdown', ()=>{
            this.click.play()
            this.scene.start("L1")
        })

        


    }
    
    

        
}
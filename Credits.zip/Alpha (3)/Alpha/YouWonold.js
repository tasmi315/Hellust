class YouWon extends Phaser.Scene{
    constructor(){
        super("YouWon");
    }
    
    preload(){
        this.load.image('win', 'assets/images/winScreen.png');
        this.load.image('credits', 'assets/images/credits.png');
        //this.load.audio('click', 'assets/audio/button.mp3');
        this.load.audio('click', 'assets/audio/button.mp3');
    }
    
    create(){
        console.log(deathCount.count);
        let playButton = this.add.image(this.game.renderer.width / 2, this.game.renderer.height-20, 'credits').setDepth(1);
        
        this.add.image(0,0, 'win').setOrigin(0);

        this.click = this.sound.add("click");
        
        playButton.setInteractive();
        
        playButton.on('pointerdown', ()=>{
            this.click.play()
            this.scene.start("Credits")
        })
        
        
    }
}
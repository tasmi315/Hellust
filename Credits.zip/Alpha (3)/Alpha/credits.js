class Creditscene extends Phaser.Scene{
    constructor(){
        super("Creditscene");
    }
    
    preload(){
        this.load.image('creditscene', 'assets/images/creditscene.png');
        this.load.image('restart', 'assets/images/playAgain.png');
    }
    
    create(){
        
        
        this.add.image(0,0, 'creditscene').setOrigin(0);
        let restart = this.add.image(this.game.renderer.width / 2, this.game.renderer.height / 1.1, 'restart').setDepth(1);
        
        restart.setInteractive();
        
        restart.on('pointerdown', ()=> {
            //this.click.play()
            this.scene.start('Menu')
        })
    }
}
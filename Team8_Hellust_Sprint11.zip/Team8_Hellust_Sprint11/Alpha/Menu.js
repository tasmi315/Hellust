class Menu extends Phaser.Scene{
    constructor(){
        super("Menu");
    }
    
    preload(){
        this.load.image('menu', 'assets/images/menu.png');
        this.load.image('start', 'assets/images/startGame.png');
        this.load.audio('soundtrack', 'assets/audio/loop.mp3');
        this.load.audio('click', 'assets/audio/button.mp3');
    }
    
    create(){
        let playButton = this.add.image(this.game.renderer.width / 2, this.game.renderer.height / 2, 'start').setDepth(1);
        
        //menu
        this.add.image(0,0, 'menu').setOrigin(0);
        
        
        // enable sound 
        this.soundtrack = this.sound.add("soundtrack");
        this.soundtrack.play(musicConfig);
        
        this.click = this.sound.add("click");
        
        playButton.setInteractive();
        
        playButton.on('pointerdown', ()=>{
            this.click.play()
            this.scene.start("Controls")
        })

    }
    
    

        
}
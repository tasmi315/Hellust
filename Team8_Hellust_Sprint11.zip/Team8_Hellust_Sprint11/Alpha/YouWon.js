class YouWon extends Phaser.Scene{
    constructor(){
        super("YouWon");
    }
    
    preload(){
        this.load.image('win', 'assets/images/winScreen.png');
        this.load.image('credits', 'assets/images/credits.png');
        this.load.audio('click', 'assets/audio/button.mp3');
    }
    
    create(){
        console.log(deathCount.count);
        let restart = this.add.image(this.game.renderer.width / 2, this.game.renderer.height / 1.2, 'credits').setDepth(1);
        this.add.image(0,0, 'win').setOrigin(0);
        
        this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' time(s).', {font: "40px Monospace", fill: "#b89e98"});
        
        restart.setInteractive();
        
        restart.on('pointerdown', ()=> {
            //this.click.play()
            this.scene.start('Credits')
        })
        
    }
}
class Menu extends Phaser.Scene{
    constructor(){
        super("Menu");
    }
    
    preload(){
        this.load.image('menu', 'assets/images/menu.png');
        this.load.image('start', 'assets/images/startGame.png');
    }
    
    create(){
        let playButton = this.add.image(this.game.renderer.width / 2, this.game.renderer.height / 2, 'start').setDepth(1);
        
        //menu
        this.add.image(0,0, 'menu').setOrigin(0);
        
        playButton.setInteractive();
        
        playButton.on('pointerdown', ()=>{
            this.scene.start("Controls")
        })

    }
    
    

        
}
class YouWon extends Phaser.Scene{
    constructor(){
        super("YouWon");
    }
    
    preload(){
        this.load.image('win', 'assets/images/winScreen.png');
    }
    
    create(){
        console.log(deathCount.count);
        
        this.add.image(0,0, 'win').setOrigin(0);
        this.add.text(134, 180, 'You Died ' + deathCount.count.toString() + ' Times', {font: "40px Monospace", fill: "#b89e98"});
        
    }
}
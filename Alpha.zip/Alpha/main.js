var gameSettings ={
    playerSpeed: 160
}

var deathCount ={
    count: 0
}

var config = {
    type: Phaser.AUTO,
    width: 600,
    height: 360,
    scene: [Menu, Controls, L1, L2, L3, L4, L5, L6, YouWon],
    physics:{
        default: 'arcade',
        arcade:{
            debug:true
        }
    }
    

};

var game = new Phaser.Game(config);


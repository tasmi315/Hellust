var gameSettings ={
    playerSpeed: 160
}
var deathCount ={
    count: 0
}

var musicConfig = {
    mute: false,
    volume: 0.75,
    rate: 1,
    detune: 0,
    seek: 0,
    loop: true,
    delay: 0,
}

var config = {
    type: Phaser.AUTO,
    width: 600,
    height: 360,
    scene: [Menu, Controls, L1, L2, L3, L4, L5, L6, YouWon],
    physics:{
        default: 'arcade',
        arcade:{
            debug:false
        }
    }
    

};

var game = new Phaser.Game(config);


class YouWon extends Phaser.Scene{
    constructor(){
        super("YouWon");
    }
    
    preload(){
        this.load.image('win', 'assets/images/winScreen.png');
    }
    
    create(){
        console.log(deathCount.count);
        
        this.add.image(0,0, 'win').setOrigin(0);
        
        this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
        
        
        /*if (deathCount == 0 ) {
            this.add.text(134, 180, '0 deaths? Not too bad.', {font: "30px Monospace", fill: "#b89e98"});
        }*/
        
        /*else if ((deathCount <= 10) and (deathCount != 0)) {
            this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
            this.add.text(134, 225, 'You could do better.', {font: "30px Monospace", fill: "#b89e98"});
        }
        
        else if ( 10 < deathCount <= 30) {
            this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
            this.add.text(134, 225, 'I\'ve seen worse', {font: "40px Monospace", fill: "#b89e98"});
        }
        
        else {
            this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
            this.add.text(134, 225, ' big OOF', {font: "40px Monospace", fill: "#b89e98"});
        }*/
    }
}
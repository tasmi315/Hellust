class YouWon extends Phaser.Scene{
    constructor(){
        super("YouWon");
    }
    
    preload(){
        this.load.image('win', 'assets/images/winScreen.png');
        this.load.image('restart', 'assets/images/playAgain.png');
        this.load.audio('click', 'assets/audio/button.mp3');
    }
    
    create(){
        console.log(deathCount.count);
        let restart = this.add.image(this.game.renderer.width / 2, this.game.renderer.height / 1.2, 'restart').setDepth(1);
        this.add.image(0,0, 'win').setOrigin(0);
        
        this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
        
        restart.setInteractive();
        
        restart.on('pointerdown', ()=> {
            //this.click.play()
            this.scene.start('Menu')
        })
        
        
        /*if (deathCount == 0 ) {
            this.add.text(134, 180, '0 deaths? Not too bad.', {font: "30px Monospace", fill: "#b89e98"});
        }*/
        
        /*else if ((deathCount <= 10) and (deathCount != 0)) {
            this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
            this.add.text(134, 225, 'You could do better.', {font: "30px Monospace", fill: "#b89e98"});
        }
        
        else if ( 10 < deathCount <= 30) {
            this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
            this.add.text(134, 225, 'I\'ve seen worse', {font: "40px Monospace", fill: "#b89e98"});
        }
        
        else {
            this.add.text(134, 180, 'You died ' + deathCount.count.toString() + ' times', {font: "40px Monospace", fill: "#b89e98"});
            this.add.text(134, 225, ' big OOF', {font: "40px Monospace", fill: "#b89e98"});
        }*/
    }
}